const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
exports.handler = async (event) => {
  try {
    const token = event.queryStringParameters?.token || '';
    const [payload, signature] = token.split('.');
    const secret = process.env.DOWNLOAD_TOKEN_SECRET;
    if (!secret || !payload || !signature) return { statusCode: 401, body: 'Invalid download link' };
    const expected = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
    const a = Buffer.from(expected), b = Buffer.from(signature);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return { statusCode: 401, body: 'Invalid download link' };
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (data.productId !== 'ai-guide' || !data.exp || data.exp < Math.floor(Date.now() / 1000)) return { statusCode: 410, body: 'Download link expired. Contact support.' };
    const file = path.join(__dirname, 'private', 'ai-guide.pdf');
    const pdf = fs.readFileSync(file);
    return { statusCode: 200, isBase64Encoded: true, headers: { 'Content-Type': 'application/pdf', 'Content-Disposition': 'attachment; filename="RAHAMAN-ONLINE-AI-Beginner-to-Advanced.pdf"', 'Cache-Control': 'no-store, private', 'X-Content-Type-Options': 'nosniff' }, body: pdf.toString('base64') };
  } catch (e) { return { statusCode: 500, body: 'Download temporarily unavailable' }; }
};
