const crypto = require('crypto');
const PRODUCTS = { 'ai-guide': { amount: 6900, currency: 'INR' } };
exports.handler = async (event) => {
  const headers = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
  try {
    const { razorpay_order_id: orderId, razorpay_payment_id: paymentId, razorpay_signature: signature, productId } = JSON.parse(event.body || '{}');
    const product = PRODUCTS[productId];
    const keyId = process.env.RAZORPAY_KEY_ID, secret = process.env.RAZORPAY_KEY_SECRET, tokenSecret = process.env.DOWNLOAD_TOKEN_SECRET;
    if (!product || !orderId || !paymentId || !signature || !keyId || !secret || !tokenSecret) return { statusCode: 400, headers, body: JSON.stringify({ error: 'Payment details or server configuration missing' }) };
    const expected = crypto.createHmac('sha256', secret).update(`${orderId}|${paymentId}`).digest('hex');
    const a = Buffer.from(expected), b = Buffer.from(signature);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return { statusCode: 400, headers, body: JSON.stringify({ error: 'Payment signature invalid' }) };
    const auth = Buffer.from(`${keyId}:${secret}`).toString('base64');
    const pr = await fetch(`https://api.razorpay.com/v1/payments/${encodeURIComponent(paymentId)}`, { headers: { Authorization: `Basic ${auth}` } });
    const payment = await pr.json();
    if (!pr.ok || payment.order_id !== orderId || payment.amount !== product.amount || payment.currency !== product.currency || !['captured'].includes(payment.status)) return { statusCode: 402, headers, body: JSON.stringify({ error: 'Payment is not captured or does not match this order' }) };
    const exp = Math.floor(Date.now() / 1000) + 15 * 60;
    const payload = Buffer.from(JSON.stringify({ productId, orderId, paymentId, exp })).toString('base64url');
    const sig = crypto.createHmac('sha256', tokenSecret).update(payload).digest('base64url');
    return { statusCode: 200, headers, body: JSON.stringify({ verified: true, downloadUrl: `/.netlify/functions/download-book?token=${payload}.${sig}` }) };
  } catch (e) { return { statusCode: 500, headers, body: JSON.stringify({ error: 'Payment verification error' }) }; }
};
