const PRODUCTS = { 'ai-guide': { amount: 6900, currency: 'INR', title: 'AI Beginner to Advanced eBook' } };
exports.handler = async (event) => {
  const headers = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
  try {
    const { productId, name, email } = JSON.parse(event.body || '{}');
    const product = PRODUCTS[productId];
    if (!product || !name || !/^\S+@\S+\.\S+$/.test(email || '')) return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid product or customer details' }) };
    const keyId = process.env.RAZORPAY_KEY_ID, keySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!keyId || !keySecret) return { statusCode: 503, headers, body: JSON.stringify({ error: 'Payment setup pending. Store owner must configure Razorpay API keys in Netlify.' }) };
    const auth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
    const response = await fetch('https://api.razorpay.com/v1/orders', { method: 'POST', headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ amount: product.amount, currency: product.currency, receipt: `ro_${Date.now()}`, notes: { productId, customerName: String(name).slice(0, 80), customerEmail: String(email).slice(0, 120) } }) });
    const order = await response.json();
    if (!response.ok) return { statusCode: 502, headers, body: JSON.stringify({ error: 'Razorpay order could not be created', details: order.error?.description || 'Gateway error' }) };
    return { statusCode: 200, headers, body: JSON.stringify({ orderId: order.id, amount: product.amount, currency: product.currency, keyId }) };
  } catch (e) { return { statusCode: 500, headers, body: JSON.stringify({ error: 'Unexpected server error' }) }; }
};
